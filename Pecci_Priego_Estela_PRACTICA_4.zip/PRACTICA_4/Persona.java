package PRACTICA_4;

import java.util.ArrayList;
import java.util.List;

public class Persona {
    private String nombre;
    private String apellido;
    private String dni;
    private int edad;
    private String email;
    private String telefono;
    private String profesion;
    private int añosExperiencia;
    private List<Libro> librosPrestados;

    public Persona(String nombre, String apellido, String dni, int edad, String email, String telefono, String profesion, int añosExperiencia) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.edad = edad;
        this.email = email;
        this.telefono = telefono;
        this.profesion = profesion;
        this.añosExperiencia = añosExperiencia;
        this.librosPrestados = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public int getAñosExperiencia() {
        return añosExperiencia;
    }

    public void setAñosExperiencia(int añosExperiencia) {
        this.añosExperiencia = añosExperiencia;
    }

    public void estaJubilado() {
        int edadCalculada = añosExperiencia + 20;
        if (edadCalculada >= 65) {
            System.out.println(nombre + " " + apellido + " está en edad de jubilación");
        } else {
            System.out.println(nombre + " " + apellido + " está en edad de trabajar");
        }
    }

    public void entrarSala(Sala sala) {
        if (sala.entrarPersona(this)) {
            System.out.println(nombre + " ha entrado a la sala " + sala.getNumero());
        }
    }

    public void salirSala(Sala sala) {
        if (sala.salirPersona(this)) {
            System.out.println(nombre + " ha salido de la sala " + sala.getNumero());
        }
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("DNI: " + dni);
        System.out.println("Edad: " + edad);
        System.out.println("Email: " + email);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Profesión: " + profesion);
        System.out.println("Años de experiencia: " + añosExperiencia);
    }
}