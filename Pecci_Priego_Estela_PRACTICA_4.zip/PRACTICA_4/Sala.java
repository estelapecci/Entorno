package PRACTICA_4;

import java.util.ArrayList;
import java.util.List;

public class Sala {
    private int numero;
    private int capacidad;
    private String tipo;
    private boolean tienePizarra;
    private boolean disponible;
    private List<Persona> personas;

    public Sala(int numero, int capacidad, String tipo, boolean tienePizarra) {
        this.numero = numero;
        this.capacidad = capacidad;
        this.tipo = tipo;
        this.tienePizarra = tienePizarra;
        this.disponible = true;
        this.personas = new ArrayList<>();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isTienePizarra() {
        return tienePizarra;
    }

    public void setTienePizarra(boolean tienePizarra) {
        this.tienePizarra = tienePizarra;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public List<Persona> getPersonas() {
        return personas;
    }

    public boolean entrarPersona(Persona persona) {
        if (personas.size() < capacidad && disponible) {
            personas.add(persona);
            return true;
        }
        return false;
    }

    public boolean salirPersona(Persona persona) {
        return personas.remove(persona);
    }

    public void mostrarPersonas() {
        System.out.println("PERSONAS EN SALA " + numero);
        for (Persona persona : personas) {
            persona.mostrarInformacion();
        }
    }

    public void estaDisponible() {
        if (disponible) {
            System.out.println("La sala " + numero + " está disponible para su reserva");
        } else {
            System.out.println("La sala " + numero + " no está disponible para su reserva");
        }
    }

    public void tienePizarra() {
        if (tienePizarra) {
            System.out.println("La sala " + numero + " dispone de pizarra");
        } else {
            System.out.println("La sala " + numero + " no dispone de pizarra");
        }
    }

    public void informacion() {
        String pizarra = tienePizarra ? "dispone de pizarra" : "no dispone de pizarra";
        String disponibilidad = disponible ? "está disponible para su reserva" : "no está disponible para su reserva";
        System.out.println("Sala: " + numero + " - Capacidad: " + capacidad + ". Se utiliza para " + tipo + ", " + pizarra + " y " + disponibilidad);
    }

    public void mostrarInformacion() {
        System.out.println("Número: " + numero);
        System.out.println("Capacidad: " + capacidad);
        System.out.println("Tipo: " + tipo);
        System.out.println("Tiene pizarra: " + tienePizarra);
        System.out.println("Disponible: " + disponible);
        System.out.println("Personas actuales: " + personas.size() + "/" + capacidad);
    }
}