package PRACTICA_4;

public class Main {
    public static void main(String[] args) {
        // Crear biblioteca con horarios
        Biblioteca biblioteca = new Biblioteca("Biblioteca Central", "Calle Principal 123", "09:00", "21:00");
        
        // Crear personas con todos los atributos
        Persona persona1 = new Persona("Juan", "Pérez", "12345678A", 25, "juan@email.com", "600111222", "Ingeniero", 5);
        Persona persona2 = new Persona("María", "Gómez", "87654321B", 30, "maria@email.com", "600333444", "Profesora", 40);
        
        // Crear libros con todos los atributos
        Libro libro1 = new Libro("Cien años de soledad", "Gabriel García Márquez", "978-8437604947", 1967, "Sudamericana", "español", 471);
        Libro libro2 = new Libro("1984", "George Orwell", "978-8499890944", 1949, "Debolsillo", "inglés", 326);
        Libro libro3 = new Libro("El Quijote", "Miguel de Cervantes", "978-8424114966", 1605, "Alfaguara", "español", 863);
        
        // Añadir libros a la biblioteca
        biblioteca.addLibro(libro1);
        biblioteca.addLibro(libro2);
        biblioteca.addLibro(libro3);
        
        // Crear salas con pizarra
        Sala sala1 = new Sala(1, 3, "Estudio", true);
        Sala sala2 = new Sala(2, 30, "Reuniones", false);
        Sala sala3 = new Sala(3, 20, "Informática", true);
        
        // Añadir salas a la biblioteca
        biblioteca.addSala(sala1);
        biblioteca.addSala(sala2);
        biblioteca.addSala(sala3);
        
        // Nuevas funcionalidades de Persona
        System.out.println("INFORMACIÓN DE PERSONAS");
        persona1.mostrarInformacion();
        persona1.estaJubilado();
        System.out.println();
        
        persona2.mostrarInformacion();
        persona2.estaJubilado();
        System.out.println();
        
        // Probar nuevas funcionalidades de Libro
        System.out.println("INFORMACIÓN DE LIBROS");
        libro1.estaDisponible();
        libro1.esExtranjero();
        libro1.informacion();
        System.out.println();
        
        libro2.estaDisponible();
        libro2.esExtranjero();
        libro2.informacion();
        System.out.println();
        
        // Probar nuevas funcionalidades de Sala
        System.out.println("INFORMACIÓN DE SALAS");
        sala1.estaDisponible();
        sala1.tienePizarra();
        sala1.informacion();
        System.out.println();
        
        // Probar funcionalidades anteriores
        System.out.println("PRUEBA ENTRAR PERSONAS A SALAS");
        persona1.entrarSala(sala1);
        persona2.entrarSala(sala1);
        
        System.out.println("\nPERSONAS EN SALA 1");
        sala1.mostrarPersonas();
        
        System.out.println("\nINFORMACIÓN COMPLETA BIBLIOTECA");
        biblioteca.mostrarBiblioteca();
        
        System.out.println("\nBUSCAR LIBRO");
        Libro libroEncontrado = biblioteca.buscarLibroPorTitulo("1984");
        if (libroEncontrado != null) {
            System.out.println("Libro encontrado:");
            libroEncontrado.mostrarInformacion();
        }
    }
}